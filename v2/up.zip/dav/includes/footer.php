<footer class="bg-dark text-inverse">
		<div class="container py-4 py-md-4">
			<div class="row gy-6 gy-lg-0">
				<div class="col-lg-12 text-center">
					<div class="widget ">
						<img class="mb-4" src="img/logo.png" height="80px" alt="" />
						<p class="mb-4">© 2023 Belwet Mind Clinic. All rights reserved.</p>						
					</div>
					<!-- /.widget -->
				</div>								
			</div>
			<!--/.row -->
		</div>
		<!-- /.container -->
	</footer>