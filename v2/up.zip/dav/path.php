<?php
    define ("ROOT_PATH", realpath(dirname(__FILE__)));
    
    define ("BASE_URL", "http://localhost/belwet/firstbelwet/v2/dav");
?>